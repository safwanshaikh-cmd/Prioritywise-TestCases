/*
 * (C) Copyright 2021 Boni Garcia (https://bonigarcia.github.io/)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package io.github.bonigarcia.wdm.versions;

import java.net.URL;
import java.util.Comparator;

/**
 * URL comparator.
 *
 * @author Boni Garcia
 * @since 5.0.0
 */
public class UrlComparator implements Comparator<URL> {

    @Override
    public int compare(URL url1, URL url2) {
        return -1 * url1.toString().compareToIgnoreCase(url2.toString());
    }
}
