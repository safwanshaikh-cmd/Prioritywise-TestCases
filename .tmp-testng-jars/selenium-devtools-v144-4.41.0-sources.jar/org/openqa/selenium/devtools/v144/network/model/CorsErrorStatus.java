package org.openqa.selenium.devtools.v144.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class CorsErrorStatus {

    private final org.openqa.selenium.devtools.v144.network.model.CorsError corsError;

    private final java.lang.String failedParameter;

    public CorsErrorStatus(org.openqa.selenium.devtools.v144.network.model.CorsError corsError, java.lang.String failedParameter) {
        this.corsError = java.util.Objects.requireNonNull(corsError, "corsError is required");
        this.failedParameter = java.util.Objects.requireNonNull(failedParameter, "failedParameter is required");
    }

    public org.openqa.selenium.devtools.v144.network.model.CorsError getCorsError() {
        return corsError;
    }

    public java.lang.String getFailedParameter() {
        return failedParameter;
    }

    private static CorsErrorStatus fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v144.network.model.CorsError corsError = null;
        java.lang.String failedParameter = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "corsError":
                    corsError = input.read(org.openqa.selenium.devtools.v144.network.model.CorsError.class);
                    break;
                case "failedParameter":
                    failedParameter = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new CorsErrorStatus(corsError, failedParameter);
    }
}
