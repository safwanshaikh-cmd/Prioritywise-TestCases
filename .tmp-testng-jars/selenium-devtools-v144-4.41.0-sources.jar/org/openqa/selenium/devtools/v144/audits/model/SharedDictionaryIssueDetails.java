package org.openqa.selenium.devtools.v144.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

public class SharedDictionaryIssueDetails {

    private final org.openqa.selenium.devtools.v144.audits.model.SharedDictionaryError sharedDictionaryError;

    private final org.openqa.selenium.devtools.v144.audits.model.AffectedRequest request;

    public SharedDictionaryIssueDetails(org.openqa.selenium.devtools.v144.audits.model.SharedDictionaryError sharedDictionaryError, org.openqa.selenium.devtools.v144.audits.model.AffectedRequest request) {
        this.sharedDictionaryError = java.util.Objects.requireNonNull(sharedDictionaryError, "sharedDictionaryError is required");
        this.request = java.util.Objects.requireNonNull(request, "request is required");
    }

    public org.openqa.selenium.devtools.v144.audits.model.SharedDictionaryError getSharedDictionaryError() {
        return sharedDictionaryError;
    }

    public org.openqa.selenium.devtools.v144.audits.model.AffectedRequest getRequest() {
        return request;
    }

    private static SharedDictionaryIssueDetails fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v144.audits.model.SharedDictionaryError sharedDictionaryError = null;
        org.openqa.selenium.devtools.v144.audits.model.AffectedRequest request = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "sharedDictionaryError":
                    sharedDictionaryError = input.read(org.openqa.selenium.devtools.v144.audits.model.SharedDictionaryError.class);
                    break;
                case "request":
                    request = input.read(org.openqa.selenium.devtools.v144.audits.model.AffectedRequest.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SharedDictionaryIssueDetails(sharedDictionaryError, request);
    }
}
