/*
 * Copyright 2014 - Present Rafael Winterhalter
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * {@link net.bytebuddy.implementation.bytecode.StackManipulation}s of this package are responsible for
 * accessing type or method members, i.e. reading and writing of fields, invoking of methods, access of local variables
 * within a method invocation or returning values from method invocations.
 */
@NeverNull.ByDefault
package net.bytebuddy.implementation.bytecode.member;

import net.bytebuddy.utility.nullability.NeverNull;
