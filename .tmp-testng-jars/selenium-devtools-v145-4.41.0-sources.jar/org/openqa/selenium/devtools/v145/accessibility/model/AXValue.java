package org.openqa.selenium.devtools.v145.accessibility.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A single computed AX property.
 */
public class AXValue {

    private final org.openqa.selenium.devtools.v145.accessibility.model.AXValueType type;

    private final java.util.Optional<java.lang.Object> value;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXRelatedNode>> relatedNodes;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXValueSource>> sources;

    public AXValue(org.openqa.selenium.devtools.v145.accessibility.model.AXValueType type, java.util.Optional<java.lang.Object> value, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXRelatedNode>> relatedNodes, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXValueSource>> sources) {
        this.type = java.util.Objects.requireNonNull(type, "type is required");
        this.value = value;
        this.relatedNodes = relatedNodes;
        this.sources = sources;
    }

    /**
     * The type of this value.
     */
    public org.openqa.selenium.devtools.v145.accessibility.model.AXValueType getType() {
        return type;
    }

    /**
     * The computed value of this property.
     */
    public java.util.Optional<java.lang.Object> getValue() {
        return value;
    }

    /**
     * One or more related nodes, if applicable.
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXRelatedNode>> getRelatedNodes() {
        return relatedNodes;
    }

    /**
     * The sources which contributed to the computation of this property.
     */
    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXValueSource>> getSources() {
        return sources;
    }

    private static AXValue fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v145.accessibility.model.AXValueType type = null;
        java.util.Optional<java.lang.Object> value = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXRelatedNode>> relatedNodes = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.accessibility.model.AXValueSource>> sources = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "type":
                    type = input.read(org.openqa.selenium.devtools.v145.accessibility.model.AXValueType.class);
                    break;
                case "value":
                    value = java.util.Optional.ofNullable(input.read(Object.class));
                    break;
                case "relatedNodes":
                    relatedNodes = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v145.accessibility.model.AXRelatedNode.class));
                    break;
                case "sources":
                    sources = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v145.accessibility.model.AXValueSource.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AXValue(type, value, relatedNodes, sources);
    }
}
