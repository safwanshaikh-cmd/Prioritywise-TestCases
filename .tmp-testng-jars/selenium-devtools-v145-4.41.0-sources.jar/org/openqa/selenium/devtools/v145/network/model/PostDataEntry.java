package org.openqa.selenium.devtools.v145.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Post data entry for HTTP request
 */
public class PostDataEntry {

    private final java.util.Optional<java.lang.String> bytes;

    public PostDataEntry(java.util.Optional<java.lang.String> bytes) {
        this.bytes = bytes;
    }

    public java.util.Optional<java.lang.String> getBytes() {
        return bytes;
    }

    private static PostDataEntry fromJson(JsonInput input) {
        java.util.Optional<java.lang.String> bytes = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "bytes":
                    bytes = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new PostDataEntry(bytes);
    }
}
