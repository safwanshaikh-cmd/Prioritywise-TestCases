package org.openqa.selenium.devtools.v145.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class SecurityIsolationStatus {

    private final java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginOpenerPolicyStatus> coop;

    private final java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginEmbedderPolicyStatus> coep;

    private final java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.network.model.ContentSecurityPolicyStatus>> csp;

    public SecurityIsolationStatus(java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginOpenerPolicyStatus> coop, java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginEmbedderPolicyStatus> coep, java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.network.model.ContentSecurityPolicyStatus>> csp) {
        this.coop = coop;
        this.coep = coep;
        this.csp = csp;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginOpenerPolicyStatus> getCoop() {
        return coop;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginEmbedderPolicyStatus> getCoep() {
        return coep;
    }

    public java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.network.model.ContentSecurityPolicyStatus>> getCsp() {
        return csp;
    }

    private static SecurityIsolationStatus fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginOpenerPolicyStatus> coop = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v145.network.model.CrossOriginEmbedderPolicyStatus> coep = java.util.Optional.empty();
        java.util.Optional<java.util.List<org.openqa.selenium.devtools.v145.network.model.ContentSecurityPolicyStatus>> csp = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "coop":
                    coop = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v145.network.model.CrossOriginOpenerPolicyStatus.class));
                    break;
                case "coep":
                    coep = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v145.network.model.CrossOriginEmbedderPolicyStatus.class));
                    break;
                case "csp":
                    csp = java.util.Optional.ofNullable(input.readArray(org.openqa.selenium.devtools.v145.network.model.ContentSecurityPolicyStatus.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new SecurityIsolationStatus(coop, coep, csp);
    }
}
