package org.openqa.selenium.devtools.v145.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Session event details specific to challenges.
 */
@org.openqa.selenium.Beta()
public class ChallengeEventDetails {

    public enum ChallengeResult {

        SUCCESS("Success"), NOSESSIONID("NoSessionId"), NOSESSIONMATCH("NoSessionMatch"), CANTSETBOUNDCOOKIE("CantSetBoundCookie");

        private String value;

        ChallengeResult(String value) {
            this.value = value;
        }

        public static ChallengeResult fromString(String s) {
            return java.util.Arrays.stream(ChallengeResult.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within ChallengeResult "));
        }

        public String toString() {
            return value;
        }

        public String toJson() {
            return value;
        }

        private static ChallengeResult fromJson(JsonInput input) {
            return fromString(input.nextString());
        }
    }

    private final ChallengeResult challengeResult;

    private final java.lang.String challenge;

    public ChallengeEventDetails(ChallengeResult challengeResult, java.lang.String challenge) {
        this.challengeResult = java.util.Objects.requireNonNull(challengeResult, "challengeResult is required");
        this.challenge = java.util.Objects.requireNonNull(challenge, "challenge is required");
    }

    /**
     * The result of a challenge.
     */
    public ChallengeResult getChallengeResult() {
        return challengeResult;
    }

    /**
     * The challenge set.
     */
    public java.lang.String getChallenge() {
        return challenge;
    }

    private static ChallengeEventDetails fromJson(JsonInput input) {
        ChallengeResult challengeResult = null;
        java.lang.String challenge = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "challengeResult":
                    challengeResult = ChallengeResult.fromString(input.nextString());
                    break;
                case "challenge":
                    challenge = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new ChallengeEventDetails(challengeResult, challenge);
    }
}
